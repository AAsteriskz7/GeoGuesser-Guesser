
# geoguesser guesser

This is a fun project that I made that is used to make guesses on geoguesser. Its a chrome extension that screenshots your tab and send it to gemini asking for a location. 

To use this, you need to clone the github/download the files to your computer. 

Then you need to get a gemini api key from google ai studio and put it in the area that says "YOUR API HERE".

Then you need to upload these files to chrome://extensions/ and then boom click the extension and it should work!
